package com.tzhh.hello.spring.cloud.service.admin.dao;

import com.tzhh.hello.spring.cloud.service.admin.entity.Msuser;
import com.tzhh.hello.spring.cloud.service.admin.tk.mybatis.MyMapper;

public interface MsuserMapper extends MyMapper<Msuser> {
}